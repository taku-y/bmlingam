# -*- coding: utf-8 -*-

"""This module includes test functions.
"""
# Author: Taku Yoshioka, Shohei Shimizu
# License: MIT

# from bmlingam.tests.test_pm3 import test_posterior_inference
from bmlingam.tests.test_find_best_model import test_find_best_model
from bmlingam.tests.test_cli import test_cli
# from bmlingam.tests.test_prob import test_laplace_gg, test_sample_gg
